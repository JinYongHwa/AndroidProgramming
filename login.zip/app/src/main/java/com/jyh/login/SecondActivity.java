package com.jyh.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    RecyclerView messageListRv;
    EditText messageEt;
    Button submitBtn;

    FirebaseFirestore firestore=FirebaseFirestore.getInstance();
    FirebaseAuth auth= FirebaseAuth.getInstance();

    List<Message> mMessageList=new ArrayList<>();
    MessageAdapter mMessageAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        messageListRv=findViewById(R.id.message_list_rv);
        messageEt=findViewById(R.id.message_et);
        submitBtn=findViewById(R.id.submit_btn);

        String email=auth.getCurrentUser().getEmail();
        mMessageAdapter=new MessageAdapter(this,mMessageList,email);
        messageListRv.setAdapter(mMessageAdapter);

        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        messageListRv.setLayoutManager(layoutManager);


        firestore.collection("message")
                .orderBy("date", Query.Direction.ASCENDING)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        List<DocumentChange> documentChangeList=value.getDocumentChanges();
                        for(DocumentChange dc :documentChangeList){
                            if(dc.getType()== DocumentChange.Type.ADDED){
                                Message message=dc.getDocument().toObject(Message.class);
                                mMessageList.add(message);
                            }
                        }
                        mMessageAdapter.notifyDataSetChanged();
                        messageListRv.scrollToPosition(mMessageList.size()-1);
                    }
                });


        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text=messageEt.getText().toString();
                if(text.equals("")){
                    return;
                }
                Toast.makeText(SecondActivity.this, text, Toast.LENGTH_SHORT).show();
                messageEt.setText("");

               Message message=new Message();
               message.setMessage(text);

               String email=auth.getCurrentUser().getEmail();
               message.setWriterId(email);

               firestore.collection("message")
                       .document()
                       .set(message);
            }
        });
    }
}
