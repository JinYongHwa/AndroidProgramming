package com.jyh.login;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Message {
    private String message;
    private String writerId;
    private Date date;

    public Message(){
        date=new Date();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getWriterId() {
        return writerId;
    }

    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getFormattedTime(){
        SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
        return sdf.format(this.date);
    }
}
