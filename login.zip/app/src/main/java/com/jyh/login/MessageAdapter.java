package com.jyh.login;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    Context mContext;
    List<Message> mMessageList;
    String mUserId;

    final int VIEWTYPE_MY=1;
    final int VIEWTYPE_OTHER=2;

    public MessageAdapter(Context context,List<Message> messageList,String userId){
        this.mContext=context;
        this.mMessageList=messageList;
        this.mUserId=userId;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType==VIEWTYPE_MY){
            View view=LayoutInflater.from(mContext).inflate(R.layout.item_message_my,parent,false);
            return new MyViewHolder(view);
        }
        else{
            View view=LayoutInflater.from(mContext).inflate(R.layout.item_message_other,parent,false);
            return new OtherViewHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message message=mMessageList.get(position);
        holder.bind(message);
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

    @Override
    public int getItemViewType(int position) {
        Message message=mMessageList.get(position);
        //메세지 작성자의 id == 앱에 로그인된 사용자 id가 같은경우
        if(mUserId.equals(message.getWriterId())){
            return VIEWTYPE_MY;
        }
        else{
            //다른사용자가 작성한 message일경우
            return VIEWTYPE_OTHER;
        }
    }

    public class OtherViewHolder extends  ViewHolder{

        TextView writerTv;
        TextView messageTv;
        TextView timeTv;

        public OtherViewHolder(@NonNull View itemView) {
            super(itemView);
            writerTv=itemView.findViewById(R.id.writer_tv);
            messageTv=itemView.findViewById(R.id.message_tv);
            timeTv=itemView.findViewById(R.id.time_tv);
        }

        @Override
        void bind(Message message) {
            writerTv.setText(message.getWriterId());
            messageTv.setText(message.getMessage());
            timeTv.setText(message.getFormattedTime());
        }
    }

    public class MyViewHolder extends ViewHolder{

        TextView messageTv;
        TextView timeTv;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            messageTv=itemView.findViewById(R.id.message_tv);
            timeTv=itemView.findViewById(R.id.time_tv);
        }

        @Override
        void bind(Message message) {
            messageTv.setText(message.getMessage());
            timeTv.setText(message.getFormattedTime());
        }
    }

    abstract public class ViewHolder extends RecyclerView.ViewHolder{

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }

        abstract void bind(Message message);
    }
}
